//
//  TBLabel.h
//  TaboolaView
//
//  Copyright © 2017 Taboola. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TBLTitleLabel : UILabel

@end
